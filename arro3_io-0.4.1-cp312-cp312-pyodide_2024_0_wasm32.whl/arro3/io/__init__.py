from ._io import *
from ._io import ___version

__version__: str = ___version()
