"""
These are constants in REBOUND default units of AU, solar masses and (yr/2pi), in which case G=1
"""

C= 10065.32012038219 # speed of light

