"""Classes that help igraph communicate with remote applications."""
